﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pog9while
{
    class Program
    {
        static void Main(string[] args)
        {
            int j = 1;
            while (j < 6)
            {
                Console.WriteLine(j);
                j++;
            }

            Console.WriteLine();
        }
    }
}
