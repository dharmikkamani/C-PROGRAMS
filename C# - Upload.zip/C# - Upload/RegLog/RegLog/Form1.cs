﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RegLog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnsbt_Click(object sender, EventArgs e)
        {
            string sel = "select * from registration where name='" + txtnm.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                string sql = "Insert into registration values('" + txtnm.Text + "','" + txtemail.Text + "','" + txtpwd.Text + "')";
                SqlDataAdapter da1 = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
            }
            else
            {
                MessageBox.Show("User already exists 0_0.","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }

        private void login_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
}
