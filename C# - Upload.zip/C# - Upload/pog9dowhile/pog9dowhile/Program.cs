﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pog9dowhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = 1;
            do
            {
                Console.WriteLine(k);
                k++;
            }
            while (k < 6);
        }
    }
}
