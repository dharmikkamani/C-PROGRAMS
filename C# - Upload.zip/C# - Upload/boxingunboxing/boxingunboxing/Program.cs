﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxingunboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 100;
            Object obj = n; // Boxing
            Console.WriteLine("N value : " + n);
            Console.WriteLine("Boxed obj value : " + obj);

            int i = (int)obj;
            Console.WriteLine("Unboxed variable  value : " + i);
            Console.ReadLine();
        }
    }
}
